
#ifndef hV_HAL_PERIPHERALS_RELEASE
#define hV_HAL_PERIPHERALS_RELEASE 700

#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>

#endif // hV_HAL_PERIPHERALS_RELEASE
